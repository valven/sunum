#!/bin/bash

rm -rf test-reports/*
mkdir test-reports

cd AndroidCalculator
~/adt-bundle-linux-x86_64-20130522/sdk/tools/android update project --name com.calculator --path . --target 1 --subprojects

cd ../AndroidCalculatorTest
~/adt-bundle-linux-x86_64-20130522/sdk/tools/android update test-project -m ../AndroidCalculator/ -p .
ant instrument

echo 'Running emulator'
~/adt-bundle-linux-x86_64-20130522/sdk/tools/emulator -avd 4.2.2 -verbose -no-window -noaudio -no-boot-anim &

sleep 90

echo 'Sending unlock scren command to Emulator'
echo "event send EV_KEY:KEY_SOFT1:1" | nc -q1 localhost 5554

echo 'Installing package'
ant installi

echo 'Running test cases'
cd ../test-reports
~/adt-bundle-linux-x86_64-20130522/sdk/platform-tools/adb shell am instrument -w -e class com.calculator.test.TestMain com.calculator.test/com.zutubi.android.junitreport.JUnitReportTestRunner
~/adt-bundle-linux-x86_64-20130522/sdk/platform-tools/adb pull /data/data/AndroidCalculator/files/junit-report.xml


echo 'Killing the emulator'
var1=$(ps -ef|grep -w emulator64 | awk '{print $2}' |head -1)

~/adt-bundle-linux-x86_64-20130522/sdk/platform-tools/adb uninstall com.calculator
~/adt-bundle-linux-x86_64-20130522/sdk/platform-tools/adb uninstall com.calculator.test

kill -9 $var1
